### MyRtools
codes for analysis 

#### 1. Struction of packages
![Struction](figure/struction.png)

#### 2. content

- visualization
- statistics
- other useful tools